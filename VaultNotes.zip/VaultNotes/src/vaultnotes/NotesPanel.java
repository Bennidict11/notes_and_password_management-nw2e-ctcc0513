/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vaultnotes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

public class NotesPanel extends JPanel {
    private DefaultListModel<String> notesListModel;
    private JList<String> notesList;
    private JTextArea noteContentArea;
    private JTextField titleField;
    private JButton saveButton, deleteButton, clearButton;

    // Store note titles and their corresponding content
    private HashMap<String, String> notesMap;

    public NotesPanel() {
        setLayout(new BorderLayout());

        notesMap = new HashMap<>();

        // Notes List
        notesListModel = new DefaultListModel<>();
        notesList = new JList<>(notesListModel);
        notesList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane listScrollPane = new JScrollPane(notesList);

        // Content Area
        noteContentArea = new JTextArea(15, 30);
        noteContentArea.setLineWrap(true);
        noteContentArea.setWrapStyleWord(true);
        JScrollPane contentScrollPane = new JScrollPane(noteContentArea);

        // Input Panel
        JPanel inputPanel = new JPanel(new BorderLayout());
        titleField = new JTextField();
        inputPanel.add(new JLabel("Note Title:"), BorderLayout.WEST);
        inputPanel.add(titleField, BorderLayout.CENTER);

        // Button Panel
        JPanel buttonPanel = new JPanel();
        saveButton = new JButton("Save Note");
        deleteButton = new JButton("Delete Note");
        clearButton = new JButton("Clear Fields");

        buttonPanel.add(saveButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(clearButton);

        // Add components to the panel
        add(listScrollPane, BorderLayout.WEST);
        add(contentScrollPane, BorderLayout.CENTER);
        add(inputPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.SOUTH);

        // Event Listeners
        saveButton.addActionListener(e -> saveNote());
        deleteButton.addActionListener(e -> deleteNote());
        clearButton.addActionListener(e -> clearFields());
        notesList.addListSelectionListener(e -> displaySelectedNote());
    }

    private void saveNote() {
        String title = titleField.getText().trim();
        String content = noteContentArea.getText().trim();

        if (title.isEmpty() || content.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Title and content cannot be empty.");
            return;
        }

        if (!notesMap.containsKey(title)) {
            // Add new title to the list
            notesListModel.addElement(title);
        }

        // Save or update note
        notesMap.put(title, content);

        JOptionPane.showMessageDialog(this, "Note saved!");
        clearFields();
    }

    private void deleteNote() {
        int selectedIndex = notesList.getSelectedIndex();
        if (selectedIndex != -1) {
            String selectedTitle = notesListModel.getElementAt(selectedIndex);
            notesListModel.remove(selectedIndex);
            notesMap.remove(selectedTitle);

            // Clear the content area if the deleted note is displayed
            noteContentArea.setText("");
            titleField.setText("");

            JOptionPane.showMessageDialog(this, "Note deleted!");
        } else {
            JOptionPane.showMessageDialog(this, "Please select a note to delete.");
        }
    }

    private void clearFields() {
        titleField.setText("");
        noteContentArea.setText("");
    }

    private void displaySelectedNote() {
        String selectedTitle = notesList.getSelectedValue();
        if (selectedTitle != null) {
            // Display the content of the selected note
            noteContentArea.setText(notesMap.get(selectedTitle));
            titleField.setText(selectedTitle);
        }
    }
}
