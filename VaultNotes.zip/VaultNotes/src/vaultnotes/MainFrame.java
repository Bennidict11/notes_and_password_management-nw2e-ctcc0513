/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vaultnotes;
import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {
    public MainFrame() {
        setTitle("VaultNotes");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Navigation Panel
        JPanel navigationPanel = new JPanel();
        JButton notesButton = new JButton("Notes");
        JButton passwordsButton = new JButton("Passwords");

        navigationPanel.add(notesButton);
        navigationPanel.add(passwordsButton);

        add(navigationPanel, BorderLayout.NORTH);

        // Main Content Area
        CardLayout cardLayout = new CardLayout();
        JPanel mainContent = new JPanel(cardLayout);

        PasswordPanel passwordPanel = new PasswordPanel();
        NotesPanel notesPanel = new NotesPanel();

        mainContent.add(notesPanel, "Notes");
        mainContent.add(passwordPanel, "Passwords");;

        add(mainContent, BorderLayout.CENTER);

        // Action Listeners
        notesButton.addActionListener(e -> cardLayout.show(mainContent, "Notes"));
        passwordsButton.addActionListener(e -> cardLayout.show(mainContent, "Passwords"));

    }
}
