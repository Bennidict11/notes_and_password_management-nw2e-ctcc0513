/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vaultnotes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

public class PasswordPanel extends JPanel {
    private DefaultListModel<String> accountListModel;
    private JList<String> accountList;
    private JTextField accountField;
    private JPasswordField passwordField;
    private JButton addButton, deleteButton, viewButton;

    // In-memory storage for passwords
    private HashMap<String, String> passwordStore;

    public PasswordPanel() {
        setLayout(new BorderLayout());

        passwordStore = new HashMap<>();

        // Account List
        accountListModel = new DefaultListModel<>();
        accountList = new JList<>(accountListModel);
        JScrollPane listScrollPane = new JScrollPane(accountList);

        // Input Panel
        JPanel inputPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        accountField = new JTextField();
        passwordField = new JPasswordField();

        inputPanel.add(new JLabel("Account Name:"));
        inputPanel.add(accountField);
        inputPanel.add(new JLabel("Password:"));
        inputPanel.add(passwordField);

        // Button Panel
        JPanel buttonPanel = new JPanel();
        addButton = new JButton("Add");
        deleteButton = new JButton("Delete");
        viewButton = new JButton("View Password");

        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(viewButton);

        // Add components to the panel
        add(listScrollPane, BorderLayout.WEST);
        add(inputPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        // Event Listeners
        addButton.addActionListener(e -> addPassword());
        deleteButton.addActionListener(e -> deletePassword());
        viewButton.addActionListener(e -> viewPassword());
    }

    private void addPassword() {
        String account = accountField.getText().trim();
        String password = new String(passwordField.getPassword());

        if (account.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Account and password cannot be empty.");
            return;
        }

        if (passwordStore.containsKey(account)) {
            JOptionPane.showMessageDialog(this, "Account already exists.");
            return;
        }

        passwordStore.put(account, password);
        accountListModel.addElement(account);
        accountField.setText("");
        passwordField.setText("");
    }

    private void deletePassword() {
        int selectedIndex = accountList.getSelectedIndex();
        if (selectedIndex != -1) {
            String account = accountListModel.getElementAt(selectedIndex);
            accountListModel.remove(selectedIndex);
            passwordStore.remove(account);
        } else {
            JOptionPane.showMessageDialog(this, "Please select an account to delete.");
        }
    }

    private void viewPassword() {
        int selectedIndex = accountList.getSelectedIndex();
        if (selectedIndex != -1) {
            String account = accountListModel.getElementAt(selectedIndex);
            String password = passwordStore.get(account);
            JOptionPane.showMessageDialog(this, "Password for " + account + ": " + password);
        } else {
            JOptionPane.showMessageDialog(this, "Please select an account to view.");
        }
    }
}
